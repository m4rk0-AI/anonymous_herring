rm -rf /var/scratch/<username>/narwhal/
cp -r ~/narwhal/ /var/scratch/<username>/
cd /var/scratch/<username>/narwhal/benchmark/
conda init
conda activate workenv
fab cluster